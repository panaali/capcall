# capcall
An Amazon Alexa App which use capital one Nessie API for answering your questions

## Ask it
Where is the nearest ATM?

